#!/usr/bin/env python
## Author - Neeraj Prem Verma

import sys
import subprocess
import json
import requests

TheHostname = subprocess.Popen("hostname",stdout=subprocess.PIPE, shell=True)
serverhostname,err = TheHostname.communicate()

TheServerIP = subprocess.Popen("curl -s http://169.254.169.254/1.0/meta-data/local-ipv4",stdout=subprocess.PIPE, shell=True)
serverip,err = TheServerIP.communicate()

TitleTail = serverhostname+serverip

SlackWebHookUrl = 'https://hooks.slack.com/services/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'
SlackChannelName = '#'+sys.argv[1]
SlackUserDisplayName = sys.argv[2]
SlackEmojiCode = ':robot_face:'

if sys.argv[3] == 'CRIT' :
	AlertDegreeColor = '#FF0049'	#Red
	MessageTitleText = 'Critical'

if sys.argv[3] == 'ALERT' :
	AlertDegreeColor = '#FF9700'	#Orange
	MessageTitleText = 'Alert'

if sys.argv[3] == 'WARN' :
	AlertDegreeColor = '#FFF700'	#Yellow
	MessageTitleText = 'Warning'

if sys.argv[3] == 'INFO' :
	AlertDegreeColor = '#A0A099'	#Grey
	MessageTitleText = 'Info'

def SlackNotif(SerMessage):
    PostData = " ".join(SerMessage)
    slack_data = { "channel": SlackChannelName ,"icon_emoji": SlackEmojiCode ,"username": SlackUserDisplayName , "attachments": [{ "color": AlertDegreeColor, "title": MessageTitleText+' : '+TitleTail , "text": PostData }]}
    response = requests.post(SlackWebHookUrl, data=json.dumps(slack_data),headers={'Content-Type': 'application/json'})
    if response.status_code != 200:
       raise ValueError('Slack Error Code : %s \nError Detail -\n%s' %(response.status_code, response.text))

SlackNotif(sys.argv[4:])
