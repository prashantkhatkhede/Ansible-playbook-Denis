#!/bin/bash 

#echo "$(date +%D-%T) : Badger was stopped, restarting the service"
    export ZOOKEEPER_HOST=zookeeper.moonfroglabs.com:2181
    /mnt/game/client.sh start
        if pgrep -x "badger_client" > /dev/null ; then
                NEWPID=$(pgrep badger_client)
                echo $NEWPID > /mnt/badger/badger.pid
            echo "$(date +%D-%T) : Badger Running with PID : $NEWPID"
            /usr/bin/python /opt/scripts/slacker.py tpg_ops Badger INFO Badger was down, auto-restarted with PID : $NEWPID
        fi
