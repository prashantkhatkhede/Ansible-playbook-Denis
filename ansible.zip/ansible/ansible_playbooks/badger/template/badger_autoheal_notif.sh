#!/bin/bash

UPTIMEINMIN=`echo $(cut -f1 -d. /proc/uptime) / 60 | bc`
STARTDELAY=$1
if [ $UPTIMEINMIN -le $STARTDELAY ] ; then
	echo "$(date +%D-%T) : Machine started $UPTIMEINMIN min ago, aborting check"
	exit 0
fi

if pgrep -x "badger_client" > /dev/null ; then
    echo "$(date +%D-%T) : Running"
    exit 0
else
    echo "$(date +%D-%T) : Badger was stopped, restarting the service"
    export ZOOKEEPER_HOST=zookeeper.moonfroglabs.com:2181
    /mnt/game/client.sh start
	if pgrep -x "badger_client" > /dev/null ; then
		NEWPID=$(pgrep badger_client)
		echo $NEWPID > /mnt/badger/badger.pid
	    echo "$(date +%D-%T) : Badger Running with PID : $NEWPID"
	    /usr/bin/python /opt/scripts/slacker.py tpg_ops Badger INFO Badger was down, auto-restarted with PID : $NEWPID
	fi
fi
