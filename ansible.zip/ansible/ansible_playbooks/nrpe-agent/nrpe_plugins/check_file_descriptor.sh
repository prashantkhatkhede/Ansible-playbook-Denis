#!/bin/bash
# Author: Mohammed Shafin T <mohammed.shafin@moonfroglabs.com>

# Nagios return codes
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3

# Help menu
print_usage() {
        echo ""
        echo "Nagios plugin to check file descriptor usage"
        echo "Usage: ./check_file_descriptor.sh <Arguments>"
        echo ""
        echo "Arguments:"
        echo "  -W <WARNING> : Nagios Warning level"
        echo "  -C <CRITICAL> : Nagios Critical level"
        echo "  -L  <LIMITS> : Ulimit Values for Hard & Soft Limits"
        echo "  -h Help menu"
        echo ""
}


Check_File_Descriptor () {
        # Check global limit
        global_max=$(cat /proc/sys/fs/file-nr 2>&1 |cut -f 3)
        global_cur=$(cat /proc/sys/fs/file-nr 2>&1 |cut -f 1)
        res=$(( $global_cur * 100 ))
        ratio=`echo "scale=2; $res / $global_max" | bc`

        if (( $(echo "$ratio > $NAGIOS_CRITICAL" |bc -l) )); then
                echo "Entered If loop"
                echo "CRITICAL global file usage $ratio% of $global_max used"
                exit $STATE_CRITICAL
        elif (( $(echo "$ratio > $NAGIOS_WARNING" |bc -l) )); then
                echo "Entered else loop"
                echo "WARNING global file usage $ratio% of $global_max used"
                exit $STATE_WARNING
        else
                echo "File Descriptor Value: OK"
                exit $STATE_OK
        fi
}

Check_Ulimit_values () {
        # Check global limit
        Hard_Limit=$(ulimit -Hn)
        Soft_Limit=$(ulimit -Sn)
        global_max=$(cat /proc/sys/fs/file-nr 2>&1 |cut -f 3)

        if [ "$Hard_Limit" -gt "$global_max" ]; then
                echo "Hard Limit: $Hard_Limit is set to a value greater than $global_max"
                exit $STATE_CRITICAL
        fi

        if [ "$Soft_Limit" -gt "$global_max" ]; then
                echo "Hard Limit: $Soft_Limit is set to a value greater than $global_max"
                exit $STATE_CRITICAL
        fi

        if [ "$Hard_Limit" -lt "$FILE_LIMIT" ]; then
    echo "CRITICAL Hard Limit is less than $FILE_LIMIT"
                exit $STATE_CRITICAL
        fi

        if [ "$Soft_Limit" -lt "$FILE_LIMIT" ]; then
                echo "CRITICAL Soft Limit is less than $FILE_LIMIT"
                exit $STATE_CRITICAL
        fi
}


# Parse parameters
if [ "$#" -eq 6 ]; then
  while [ $# -gt 0 ]; do
      case "$1" in
          -h | --help)
              print_usage
              exit $STATE_OK
              ;;
          -W)
              shift
              NAGIOS_WARNING=$1
              ;;
          -C)
              shift
              NAGIOS_CRITICAL=$1
              ;;
          -L)
              shift
              FILE_LIMIT=$1
              ;;
          *)  echo "Unknown argument: $1"
              print_usage
              exit $STATE_UNKNOWN
              ;;
          esac
      shift
  done
else
  echo "Arguments Missing / Invalid Arguments"
        print_usage
        exit $STATE_UNKNOWN
fi

Check_Ulimit_values
Check_File_Descriptor
