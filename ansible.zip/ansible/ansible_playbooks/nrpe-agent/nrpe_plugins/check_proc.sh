#!/bin/bash
# ========================================================================================
# Nagios plugin to check Process Statistics
#
# Written by	: Denis D'Souza
# Creation date : 20 Aug 2018
# Description   : Nagios plugin (bash script) to check process statistics.
#		          This script has been designed for Linux plateform only,
#                 Tested on Ubuntu 14.04
#
# Usage         : ./check_process.sh [-M <Metric type>] [-P <PID file>] [-W <WARNING>] [-C <CRITICAL>]
#                                     Valid Mertic types:
#                                     STAT   - Process is running or not (usees pgrep command)
#                                     PCPU   - CPU usage for process (uses ps command)
#                                     PMEM   - Memory usage for process (uses ps command)
#
# ----------------------------------------------------------------------------------------
# ========================================================================================

# Nagios return codes
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3

# Help menu
print_usage() {
	echo ""
	echo "Nagios plugin to check Process Statistics"
	echo "Usage: ./check_process.sh [flags]"
	echo ""
	echo "Flags:"
	echo "  -M  <Metric type> : The process metic to check"
    echo "        Valid Mertic types:"
    echo "          STAT   - Process is running or not (uses pgrep command)"
    echo "          PCPU   - CPU usage for process (will check PCPU for individual child-processes if they exist)(uses ps command)"
    echo "          PMEM   - Memory usage for process (uses ps command)"
	echo "  -P <PID file> : Path to PID file"
	echo "  -W <WARNING> : Nagios Warning level"
	echo "  -C <CRITICAL> : Nagios Critical level"
	echo "  -h Help menu"
	echo ""
}

# Parse parameters
while [ $# -gt 0 ]; do
    case "$1" in
        -h | --help)
            print_usage
            exit $STATE_OK
            ;;
        -M)
            shift
            METRIC=$1
            ;;
        -P)
            shift
            PID_FILE=$1
            ;;
        -W)
            shift
            NAGIOS_WARNING=$1
            ;;
        -C)
            shift
            NAGIOS_CRITICAL=$1
            ;;
        *)  echo "Unknown argument: $1"
            print_usage
            exit $STATE_UNKNOWN
            ;;
        esac
    shift
done

# Check if the Process is running or not
Check_STAT () {
    if [ -f $PID_FILE ]; then
        /bin/ps -p `cat $PID_FILE` --no-headers > /dev/null 2>&1
        OUTPUT=$?
        if [ $OUTPUT == 1 ]; then
            echo "CRITICAL: Process is not running"
            exit $STATE_CRITICAL
        else
            echo "OK: Process is running"
            exit $STATE_OK
        fi
    else
        echo "UNKNOWN: PID file not found"
        exit $STATE_UNKNOWN
    fi
}

# Check if the Process has child-processes
Check_child () {
    if [ -f $PID_FILE ]; then
        /bin/ps -p `cat $PID_FILE` --no-headers > /dev/null 2>&1
        OUTPUT=$?
        if [ $OUTPUT == 1 ]; then
            echo "CRITICAL: Process is not running"
            exit $STATE_CRITICAL
        else
            PID_VAL=`cat $PID_FILE`
            PROC_COUNT=$(/usr/bin/pgrep -P $PID_VAL| wc -l)
        fi
    else
        echo "UNKNOWN: PID file not found"
        exit $STATE_UNKNOWN
    fi
}

# Check PCPU for indivitual child-processes if they exist, else check PCPU for main process
Check_PCPU () {
   Check_child
   if [ $PROC_COUNT -gt 0 ]; then
        for CHILD in `/usr/bin/pgrep -P $PID_VAL`
        do
            PCPU_VAL=`/bin/ps -p $CHILD -o %cpu --no-headers`
            PCPU_VAL_INT=${PCPU_VAL%.*}
            if [ $PCPU_VAL_INT -ge $NAGIOS_WARNING ] && [ $PCPU_VAL_INT -lt $NAGIOS_CRITICAL ]; then
                CHILD+=$(echo ":$PCPU_VAL_INT")
                CHILD+="%"
                WARN_PCPU+=("$CHILD")
                elif [ $PCPU_VAL_INT -ge $NAGIOS_CRITICAL ]; then
		            CHILD+=$(echo ":$PCPU_VAL_INT")
		            CHILD+="%"
                    CRIT_PCPU+=("$CHILD")
            else
                CHILD+=$(echo ":$PCPU_VAL_INT")
                CHILD+="%"
                OK_PCPU+=("$CHILD")
            fi
        done

        if [ ${#WARN_PCPU[@]} == 0 ] && [ ${#CRIT_PCPU[@]} == 0 ]; then
           echo "OK: PCPU is OK for all child-processes: ${OK_PCPU[@]}"
           exit $STATE_OK
           elif [ ${#CRIT_PCPU[@]} -gt 0 ]; then
                if [ ${#WARN_PCPU[@]} == 0 ]; then
                    echo "CRITICAL: PCPU is CRITICAL for child-processes: ${CRIT_PCPU[@]}"
                else
                    echo "CRITICAL: PCPU is CRITICAL for child-processes: ${CRIT_PCPU[@]} And WARNING for child-processes: ${WARN_PCPU[@]}"
                fi
            exit $STATE_CRITICAL
        else
            echo "WARNING: PCPU is WARNING for child-processes: ${WARN_PCPU[@]}"
            exit $STATE_WARNING
        fi
    else
        PCPU_VAL=`ps -p $(cat $PID_FILE) -o %cpu --no-headers`
        PCPU_VAL_INT=${PCPU_VAL%.*}
        PCPU_VAL_INT_PER=${PCPU_VAL%.*}
        PCPU_VAL_INT_PER+="%"
        if [ $PCPU_VAL_INT -ge $NAGIOS_WARNING ] && [ $PCPU_VAL_INT -lt $NAGIOS_CRITICAL ]; then
            echo "WARNING: PCPU is warning for Master-process: $PCPU_VAL_INT_PER"
            exit $STATE_WARNING
            elif [ $PCPU_VAL_INT -gt $NAGIOS_CRITICAL ]; then
                echo "CRITICAL: PCPU is critical for Master-process: $PCPU_VAL_INT_PER"
                exit $STATE_CRITICAL
        else
            echo "OK: PCPU is ok for Master-process: $PCPU_VAL_INT_PER"
            exit $STATE_OK
        fi

    fi
}

# Check Memory used by process (total memory)
Check_PMEM () {
    Check_child
    TOTAL_PMEM=0
    if [ $PROC_COUNT -gt 0 ]; then
        for CHILD in `/usr/bin/pgrep -P $PID_VAL`
        do
            PMEM_VAL=`/bin/ps -p $CHILD -o %mem --no-headers`
            PMEM_VAL_INT=${PMEM_VAL%.*}
            TOTAL_PMEM="$(($TOTAL_PMEM + $PMEM_VAL_INT ))"
        done

        PMEM_VAL=`/bin/ps -p $PID_VAL -o %mem --no-headers`
        PMEM_VAL_INT=${PMEM_VAL%.*}
        TOTAL_PMEM="$(($TOTAL_PMEM + $PMEM_VAL_INT ))"
        TOTAL_PMEM_PERCENT=$TOTAL_PMEM
        TOTAL_PMEM_PERCENT+="%"

        if [ $TOTAL_PMEM -ge $NAGIOS_WARNING ] && [ $TOTAL_PMEM -lt $NAGIOS_CRITICAL ]; then
            echo "WARNING: Memory for process: $TOTAL_PMEM_PERCENT"
            exit $STATE_WARNING
            elif [ $TOTAL_PMEM -gt $NAGIOS_CRITICAL ]; then
                echo "CRITICAL: Memory for process: $TOTAL_PMEM_PERCENT"
                exit $STATE_CRITICAL
        else
            echo "OK: Memory for process: $TOTAL_PMEM_PERCENT"
            exit $STATE_OK
        fi
    else
        PMEM_VAL=`ps -p $(cat $PID_FILE) -o %mem --no-headers`
        PMEM_VAL_INT=${PMEM_VAL%.*}
        PMEM_VAL_INT_PER=${PMEM_VAL%.*}
        PMEM_VAL_INT_PER+="%"
        if [ $PMEM_VAL_INT -ge $NAGIOS_WARNING ] && [ $PMEM_VAL_INT -lt $NAGIOS_CRITICAL ]; then
            echo "WARNING: Memory for process: $PMEM_VAL_INT_PER"
            exit $STATE_WARNING
        elif [ $PMEM_VAL_INT -gt $NAGIOS_CRITICAL ]; then
            echo "CRITICAL: Memory for process: $PMEM_VAL_INT_PER"
            exit $STATE_CRITICAL
        else
            echo "OK: Memory for process: $PMEM_VAL_INT_PER"
            exit $STATE_OK
        fi
    fi
}

# Validate the provided arguments
Check_metric_argument () {
    if [ -z $METRIC ]; then
        echo "Please Provide Arguments"
        exit $STATE_UNKNOWN
        elif [ $METRIC == STAT ]; then
            Check_STAT
        elif [ $METRIC == PCPU ]; then
            Check_PCPU
        elif [ $METRIC == PMEM ]; then
            Check_PMEM
    else
        echo "Incorrect Argument Provided"
        exit $STATE_UNKNOWN
    fi
}

Check_metric_argument
