#!/bin/bash
#Author: Denis DSouza<denis.dsouza@moonfroglabs.com> Modified by Koushik

NAGIOSDIR="/etc/nagios"
NRPECFG="nrpe.cfg"
DBDISK="command\[check_db_disk\]"

# Set the Nagios Warning and Critical values
WARNING=20
CRITICAL=15

#function to check if configuration for specific mountpoint exists in config file
DBDISK-monitored () {
	grep "$DBDISK" $NRPECFG
	#if grep was able to find the string/pattern the exit code will be 0 else 1
	DBOUTPUT=$?
}

cd $NAGIOSDIR
#check if NRPE config file exists
if [ -e $NRPECFG ]; then
	echo "NRPE config file exists $NRPECFG"
	DBDISK-monitored
	if [ $DBOUTPUT = 0 ]; then
		echo "DB DISK is monitored"
		#change the Warning and Critical vaues in string/line
		sed -i "/command\[check_db_disk\]/ s/w [0-9][0-9]%/w $WARNING%/g" $NRPECFG ;
		sed -i "/command\[check_db_disk\]/ s/c [0-9][0-9]%/c $CRITICAL%/g" $NRPECFG ;
	fi

else
	echo "$NRPECFG doees not exist"
fi
