#!/bin/bash
#Author: Denis DSouza<denis.dsouza@moonfroglabs.com>

NAGIOSDIR="/etc/nagios"
NRPECFG="nrpe.cfg"
ROOTDISK="command\[check_root_disk\]"
MNTDISK="command\[check_mnt_disk\]"
MNT2DISK="command\[check_mnt2_disk\]"
DBDISK="command\[check_db_disk\]"

# Set the Nagios Warning and Critical values
WARNING=15
CRITICAL=10

#function to check if configuration for specific mountpoint exists in config file
Disks-monitored () {
	grep "$ROOTDISK" $NRPECFG
	#if grep was able to find the string/pattern the exit code will be 0 else 1
	ROOTOUTPUT=$?
	grep "$MNTDISK" $NRPECFG
	MNTOUTPUT=$?
	grep "$MNT2DISK" $NRPECFG
	MNT2OUTPUT=$?
	grep "$DBDISK" $NRPECFG
	DBOUTPUT=$?
}

cd $NAGIOSDIR
#check if NRPE config file exists
if [ -e $NRPECFG ]; then
	echo "NRPE config file exists $NRPECFG"
	Disks-monitored
	if [ $ROOTOUTPUT = 0 ]; then
		echo "/ is monitored"
		#change the Warning and Critical vaues in string/line
		sed -i "/command\[check_root_disk\]/ s/w [0-9][0-9]%/w $WARNING%/g" $NRPECFG ;
		sed -i "/command\[check_root_disk\]/ s/c [0-9][0-9]%/c $CRITICAL%/g" $NRPECFG ;
	fi

#	 if [ $MNTOUTPUT = 0 ]; then
#		echo "/mnt is monitored"
#		sed -i "/command\[check_mnt_disk\]/ s/w [0-9][0-9]%/w $WARNING%/g" $NRPECFG ;
#		sed -i "/command\[check_mnt_disk\]/ s/c [0-9][0-9]%/c $CRITICAL%/g" $NRPECFG ;
#	fi

#	if [ $MNT2OUTPUT = 0 ]; then
#		echo "/mnt2 is monitored"
#		sed -i "/command\[check_mnt2_disk\]/ s/w [0-9][0-9]%/w $WARNING%/g" $NRPECFG ;
#		sed -i "/command\[check_mnt2_disk\]/ s/c [0-9][0-9]%/c $CRITICAL%/g" $NRPECFG ;
#	fi

#	if [ $DBOUTPUT = 0 ]; then
#		echo "/db is monitored"
#		sed -i "/command\[check_db_disk\]/ s/w [0-9][0-9]%/w $WARNING%/g" $NRPECFG ;
#		sed -i "/command\[check_db_disk\]/ s/c [0-9][0-9]%/c $CRITICAL%/g" $NRPECFG ;
#	fi

	#Restart the NRPE agent
	service nagios-nrpe-server restart
else
	echo "$NRPECFG doees not exist"
fi
