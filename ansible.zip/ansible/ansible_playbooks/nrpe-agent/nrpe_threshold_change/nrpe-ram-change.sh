#!/bin/bash
#Author: Denis DSouza<denis.dsouza@moonfroglabs.com>

NAGIOSDIR="/etc/nagios"
NRPECFG="nrpe.cfg"
RAMCMD="command\[check_mem\]"

# Set the Nagios Warning and Critical values
WARNING=85
CRITICAL=90

#function to check if configuration for specific mountpoint exists in config file
RAM-monitored () {
	grep "$RAMCMD" $NRPECFG
	#if grep was able to find the string/pattern the exit code will be 0 else 1
	RAMOUTPUT=$?
}

cd $NAGIOSDIR
#check if NRPE config file exists
if [ -e $NRPECFG ]; then
	echo "NRPE config file exists $NRPECFG"
	RAM-monitored
	if [ $RAMOUTPUT = 0 ]; then
		echo "Memory/RAM is monitored"
		#change the Warning and Critical vaues in string/line
		sed -i "/command\[check_mem\]/ s/w [0-9][0-9]/w $WARNING/g" $NRPECFG ;
		sed -i "/command\[check_mem\]/ s/c [0-9][0-9]/c $CRITICAL/g" $NRPECFG ;
	fi

else
	echo "$NRPECFG doees not exist"
fi
