#!/bin/bash
PORTS=`netstat -tunlp | grep redis | grep tcp6 | awk  {'print $4'} | cut -d ':' -f4`
ARR_PORTS=($PORTS)

TEXT2="declare -a REDIS_PORTS=(${ARR_PORTS[@]})"

echo $TEXT2

sed -i '/declare -a REDIS_PORTS=(empty)/c\'"$TEXT2" /usr/lib/nagios/plugins/check_redis
sed -i '/declare -a REDIS_PORTS=(empty)/c\'"$TEXT2" /usr/lib/nagios/plugins/check_bgsave
