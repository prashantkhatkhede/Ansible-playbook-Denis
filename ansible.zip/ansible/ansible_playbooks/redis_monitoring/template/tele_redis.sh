#!/bin/bash
INPUT_REDIS="/etc/telegraf/telegraf.d/redport.conf"
PORTS=`netstat -tunlp | grep redis | grep tcp6 | awk  {'print $4'} | cut -d ':' -f4`
ARR_PORTS=($PORTS)
echo "Ports: ${ARR_PORTS[@]}"
if [ ${#ARR_PORTS[@]} -eq 11 ]; then
    echo "[[inputs.redis]]" > $INPUT_REDIS
    echo " servers = [\"tcp://localhost:${ARR_PORTS[0]}\",\"tcp://localhost:${ARR_PORTS[1]}\",\"tcp://localhost:${ARR_PORTS[2]}\",\"tcp://localhost:${ARR_PORTS[3]}\",\"tcp://localhost:${ARR_PORTS[4]}\",\"tcp://localhost:${ARR_PORTS[5]}\",\"tcp://localhost:${ARR_PORTS[6]}\",\"tcp://localhost:${ARR_PORTS[7]}\",\"tcp://localhost:${ARR_PORTS[8]}\",\"tcp://localhost:${ARR_PORTS[9]}\",\"tcp://localhost:${ARR_PORTS[10]}\"]" >> $INPUT_REDIS

elif [ ${#ARR_PORTS[@]} -eq 10 ]; then
    echo "[[inputs.redis]]" > $INPUT_REDIS
    echo " servers = [\"tcp://localhost:${ARR_PORTS[0]}\",\"tcp://localhost:${ARR_PORTS[1]}\",\"tcp://localhost:${ARR_PORTS[2]}\",\"tcp://localhost:${ARR_PORTS[3]}\",\"tcp://localhost:${ARR_PORTS[4]}\",\"tcp://localhost:${ARR_PORTS[5]}\",\"tcp://localhost:${ARR_PORTS[6]}\",\"tcp://localhost:${ARR_PORTS[7]}\",\"tcp://localhost:${ARR_PORTS[8]}\",\"tcp://localhost:${ARR_PORTS[9]}\"]" >> $INPUT_REDIS
elif [ ${#ARR_PORTS[@]} -eq 3 ]; then
    echo "[[inputs.redis]]" > $INPUT_REDIS
    echo " servers = [\"tcp://localhost:${ARR_PORTS[0]}\",\"tcp://localhost:${ARR_PORTS[1]}\",\"tcp://localhost:${ARR_PORTS[2]}\"]" >> $INPUT_REDIS
elif [ ${#ARR_PORTS[@]} -eq 2 ]; then
    echo "[[inputs.redis]]" > $INPUT_REDIS
    echo " servers = [\"tcp://localhost:${ARR_PORTS[0]}\",\"tcp://localhost:${ARR_PORTS[1]}\"]" >> $INPUT_REDIS
elif [ ${#ARR_PORTS[@]} -eq 1 ]; then
    echo "[[inputs.redis]]" > $INPUT_REDIS
    echo " servers = [\"tcp://localhost:${ARR_PORTS[0]}\"]" >> $INPUT_REDIS
else
    echo "Number of ports is above 4 or Redis is not running"
fi
