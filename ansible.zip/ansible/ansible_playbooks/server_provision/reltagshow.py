#!/usr/bin/env/ python

import sys
from kazoo.client import KazooClient
zk = KazooClient(hosts="tpgzk.moonfroglabs.com:2181", read_only=True)
zk.start()
data, stat = zk.get("/release/tag_new")
print (data.decode("utf-8"))
zk.stop()
