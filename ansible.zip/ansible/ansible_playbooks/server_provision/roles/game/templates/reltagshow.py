#!/usr/bin/env/ python

import sys
from kazoo.client import KazooClient
try:
  reltag_field = sys.argv[1]
  zk = KazooClient(hosts="tpgzk.moonfroglabs.com:2181", read_only=True)
  zk.start()
  data, stat = zk.get("/release/"+reltag_field)
  print (data.decode("utf-8"))
  zk.stop()
except:
  print "Wrong ZK Value"
