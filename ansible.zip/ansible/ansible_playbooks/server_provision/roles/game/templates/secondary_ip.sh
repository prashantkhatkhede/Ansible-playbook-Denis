#!/bin/bash
MAC=`curl -s http://169.254.169.254/latest/meta-data/mac`
ADDRESSES=`curl -s http://169.254.169.254/latest/meta-data/network/interfaces/macs/${MAC}/local-ipv4s`
SUBNET=`ip r | grep src |awk {'print $1'} | awk -F / {'print $2'}`
ARR=($ADDRESSES)
if [ ${#ARR[@]} -ge 2 ];
then
  ip addr add ${ARR[1]}/$SUBNET dev eth0
  exit 0
else
   echo "Secondary IP-address not allocated, Please allocate a Secondary IP"
   exit 1
fi
