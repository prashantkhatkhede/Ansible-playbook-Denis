#!/bin/bash
#Author: Denis DSouza<denis.dsouza@moonfroglabs.com>

TELEGDIR="/etc/telegraf"
TELEGCFG="$TELEGDIR/telegraf.conf"
URL="http:\/\/"
PUBIP="52.74.239.48"
INTIP="172.31.11.235"
OLDURL="metrics.moonfroglabs.com"
NEWURL="metricsdata.moonfroglabs.com"

#function to check if configuration for specific mountpoint exists in config file
check-url () {
	grep -e $URL$PUBIP $TELEGCFG | grep -v "^ *#"
	grep -e $URL$INTIP $TELEGCFG | grep -v "^ *#"
	#if grep was able to find the string/pattern the exit code will be 0 else 1
}

check-newurl () {
        grep -e $NEWURL $TELEGCFG | grep -v "^ *#"
        #grep -e $URL$INTIP $TELEGCFG | grep -v "^ *#"
        #if grep was able to find the string/pattern the exit code will be 0 else 1
}


#cd $TELEGDIR
#check if NRPE config file exists
if [ -e $TELEGCFG ]; then
	#cd $TELEGDIR
	echo "Telegraf config file exists $TELEGCFG"
	check-url
	#change the Warning and Critical vaues in string/line
	sed -i "s/$PUBIP\b/$NEWURL/g" $TELEGCFG
	sed -i "s/$INTIP\b/$NEWURL/g" $TELEGCFG
	sed -i "s/$OLDURL\b/$NEWURL/g" $TELEGCFG
	check-newurl
	#Restart the NRPE agent
	#service telegraf restart
else
	echo "$TELEGCFG doees not exist"
fi
